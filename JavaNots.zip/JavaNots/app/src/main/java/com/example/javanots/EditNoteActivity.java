package com.example.javanots;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class EditNoteActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_note);
    }
}